﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.Marshalling;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public interface Entity : ICloneable
    {
        public void CargarPK(int ID) { this.ID = ID; }
        public abstract void CargarDatos(object[] d);
        public abstract object[] DevolverDatos();
        public object DevolverPK() => ID;
        public string ToString();
        public int ID {  get; set; }
        public abstract object Clone();
    }
}
