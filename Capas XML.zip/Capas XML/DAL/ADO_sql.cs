﻿using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Reflection.Metadata;

namespace DAL
{
    public class ADO_sql
    {
        DataSet ds;
        public ADO_sql()
        {
            ds = new DataSet("pruebaXML");
            if (File.Exists("datos.xml"))
            {
                ds.ReadXml("datos.xml");
            }
            else
            {
                DataTable clientes = new DataTable("clientes");

                clientes.Columns.Add("ID", typeof(int));
                clientes.Columns.Add("Cliente", typeof(string));
                clientes.Columns.Add("Telefono", typeof(string));
                clientes.Columns.Add("Correo", typeof(string));

                ds.Tables.Add(clientes);

                DataTable productos = new DataTable("productos");

                productos.Columns.Add("ID", typeof(int));
                productos.Columns.Add("Nombre", typeof(string));
                productos.Columns.Add("Precio", typeof(float));
                productos.Columns.Add("Categoria", typeof(string));

                ds.Tables.Add(productos);

                DataTable ventas = new DataTable("ventas");

                ventas.Columns.Add("ID", typeof(int));
                ventas.Columns.Add("IDCliente", typeof(int));
                ventas.Columns.Add("Fecha", typeof(DateTime));
                ventas.Columns.Add("Total", typeof(float));

                ds.Tables.Add(ventas);

                DataTable ventasitems = new DataTable("ventasitems");

                ventasitems.Columns.Add("ID", typeof(int));
                ventasitems.Columns.Add("IDVenta", typeof(int));
                ventasitems.Columns.Add("IDProducto", typeof(int));
                ventasitems.Columns.Add("PrecioUnitario", typeof(float));
                ventasitems.Columns.Add("Cantidad", typeof(float));
                ventasitems.Columns.Add("PrecioTotal", typeof(float));

                ds.Tables.Add(ventasitems);

                ds.Tables["productos"].PrimaryKey = new DataColumn[] { ds.Tables["productos"].Columns[0] };
                ds.Tables["clientes"].PrimaryKey = new DataColumn[] { ds.Tables["clientes"].Columns[0] };
                ds.Tables["ventas"].PrimaryKey = new DataColumn[] { ds.Tables["ventas"].Columns[0] };
                ds.Tables["ventasitems"].PrimaryKey = new DataColumn[] { ds.Tables["ventasitems"].Columns[0] };

            }    
        }
        public DataSet DevolverDataSet() { return ds; }
        public void Guardar() 
        {
            ds.WriteXml("datos.xml", XmlWriteMode.WriteSchema);
            ds.AcceptChanges(); 
        }
    }
}
