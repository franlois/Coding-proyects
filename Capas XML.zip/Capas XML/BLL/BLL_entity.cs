﻿using BE;
using ORM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_entity
    {
        Mapeador mapa;
        public BLL_entity()
        {
            mapa = new Mapeador();
        }
        public bool Alta(Entity e)
        {
            return mapa.Alta(e);
        }
        public bool Baja(Entity e)
        {
            return mapa.Baja(e);
        }
        public bool Modificacion(Entity e)
        {
            return mapa.Modificacion(e);
        }
        public List<T> DevolverTabla<T>(T entity) where T : Entity, new()
        {
            return mapa.DevolverTabla(entity);
        }
        public void ConsultaID<T>(T e) where T : Entity, new()
        {
            e.CargarDatos(mapa.ConsultaXCondicion($"ID = {e.ID}", new T())[0].DevolverDatos());
        }
        public List<T> ConsultaDesdeHastaID<T>(T entLimiteInf, T entLimiteSuperior) where T : Entity, new()
        {
            return mapa.ConsultaXCondicion($"ID >= {entLimiteInf.ID} AND ID <= {entLimiteSuperior.ID}", new T());
        }
        public List<clientes> ConsultaIncrementalID(clientes ent)
        {
            return mapa.ConsultaXCondicion($"Cliente like '{ent.Nombre}%'", new clientes());
        }
        // esta bien el dataviewrow state aca?
        public List<T>MostrarModificadosClienteOG<T>() where T : Entity, new()
        {
            return mapa.ConsultaXestado(System.Data.DataViewRowState.ModifiedOriginal, new T());
        }
        public List<T> MostrarModificadosNEW<T>() where T:Entity, new()
        {
            return mapa.ConsultaXestado(System.Data.DataViewRowState.ModifiedCurrent, new T());
        }
        public List<T>MostrarNuevos<T>() where T:Entity, new()
        {
            return mapa.ConsultaXestado(System.Data.DataViewRowState.Added, new T());
        }
        public List<T>MostrarBorrados<T>() where T:Entity, new()
        {
            return mapa.ConsultaXestado(System.Data.DataViewRowState.Deleted, new T());
        }
        public void GrabarEnBd()
        {
            mapa.Guardar();
        }
    }
}
