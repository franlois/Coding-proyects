﻿using BE;
using BLL;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_capas_2
{
    public partial class Formulario_productos : Form1
    {
        public Formulario_productos()
        {
            InitializeComponent();
            OcultarBotones();
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = Interaction.InputBox("ingrese el id");
            string nombre = Interaction.InputBox("ingrese el nombre");
            string precio = Interaction.InputBox("ingrese el telefono");
            string categoria = Interaction.InputBox("ingrese el mail");
            object[] d = new object[] { id, nombre, precio, categoria };
            if (ValidacionesProducto(d)) Alta<productos>(d);
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }
        private bool ValidacionesProducto(object[] d)
        {
            if (Information.IsNumeric(d[0]) && Information.IsNumeric(d[2]))
            {
                if (bll.DevolverTabla(new productos()).ToList().Find(x => x.ID == Convert.ToInt16(d[0])) == null) return true;
            }
            return false;
        }
        private bool ValidacionesProducto2(object[] d)
        {
            if (Information.IsNumeric(d[2])) return true;
            return false;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            bll.GrabarEnBd();
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Baja<productos>(Convert.ToInt16(dataGridView1.SelectedRows[0].Cells[0].Value.ToString()));
                CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string nombre = Interaction.InputBox("ingrese el nombre");
            string precio = Interaction.InputBox("ingrese el telefono");
            string categoria = Interaction.InputBox("ingrese el mail");
            object[] d = new object[] { id, nombre, precio, categoria };
            if (ValidacionesProducto2(d)) Modificacion<productos>(d);
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0 && Information.IsNumeric(textBox1.Text) && textBox2.Text.Length > 0 && Information.IsNumeric(textBox2.Text))
            {
                productos aux1 = new productos();
                productos aux2 = new productos();
                aux1.CargarPK(Convert.ToInt16(textBox1.Text));
                aux2.CargarPK(Convert.ToInt16(textBox2.Text));
                ConsultaDesdeHasta(aux1, aux2, dataGridView6);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox4.Text.Length > 0 && Information.IsNumeric(textBox4.Text))
            {
                productos aux = new productos();
                aux.CargarPK(Convert.ToInt16(textBox4.Text));
                ConsultaXID(aux, dataGridView8);
            }
        }
    }
}
