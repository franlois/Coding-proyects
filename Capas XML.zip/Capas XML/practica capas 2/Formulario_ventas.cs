﻿using BE;
using BLL;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_capas_2
{
    public partial class Formulario_ventas : Form1
    {
        public Formulario_ventas()
        {
            InitializeComponent();
            OcultarBotones();
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = Interaction.InputBox("ingrese el id");
            string id_cliente = Interaction.InputBox("ingrese el nombre");
            string fecha = Interaction.InputBox("ingrese el telefono");
            string total = Interaction.InputBox("ingrese el mail");
            object[] d = new object[] { id, id_cliente, fecha, total };
            if (ValidarVentas(d)) { Alta<ventas>(d); }
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private bool ValidarVentas(object[] d)
        {
            if (Information.IsNumeric(d[0]) && Information.IsNumeric(d[1]) && Information.IsNumeric(d[3]))
            {
                Regex regex = new Regex(@"^\d{2}/\d{2}/\d{4}$");
                if (regex.IsMatch(d[2].ToString()))
                {
                    if (bll.DevolverTabla(new clientes()).ToList().Find(x => x.ID == Convert.ToInt16(d[1])) != null && bll.DevolverTabla(new ventas()).ToList().Find(x => x.ID == Convert.ToInt16(d[0])) == null) { return true; }
                }
            }
            return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Baja<ventas>(Convert.ToInt16(dataGridView1.SelectedRows[0].Cells[0].Value));
                CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(dataGridView1.Rows.Count > 0)
            {
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string id_cliente = Interaction.InputBox("ingrese el nombre", "", dataGridView1.SelectedRows[0].Cells[1].Value.ToString());
                string fecha = Interaction.InputBox("ingrese el telefono", "", dataGridView1.SelectedRows[0].Cells[2].Value.ToString());
                string total = Interaction.InputBox("ingrese el mail", "", dataGridView1.SelectedRows[0].Cells[3].Value.ToString());
                object[] d = new object[] { id, id_cliente, fecha, total };
                if (ValidarVentas(d)) { Modificacion<ventas>(d); CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5); }
            }
            /*if (dataGridView1.Rows.Count > 0)
            {
                ventas aux = bll.DevolverTabla(new ventas()).ToList().Find(x => x.ID == Convert.ToInt16(dataGridView1.SelectedRows[0].Cells[0].Value));
            }*/
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bll.GrabarEnBd();
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0 && Information.IsNumeric(textBox1.Text) && textBox2.Text.Length > 0 && Information.IsNumeric(textBox2.Text))
            {
                ventas aux1 = new ventas();
                ventas aux2 = new ventas();
                aux1.CargarPK(Convert.ToInt16(textBox1.Text));
                aux2.CargarPK(Convert.ToInt16(textBox2.Text));
                ConsultaDesdeHasta(aux1, aux2, dataGridView6);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox4.Text.Length > 0 && Information.IsNumeric(textBox4.Text))
            {
                ventas aux = new ventas();
                aux.CargarPK(Convert.ToInt16(textBox4.Text));
                ConsultaXID(aux, dataGridView8);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
