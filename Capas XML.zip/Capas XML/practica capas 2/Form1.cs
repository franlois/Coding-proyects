using BE;
using BLL;

namespace practica_capas_2
{
    public partial class Form1 : Form
    {
        protected BLL_entity bll;
        Formulario_clientes clientess;
        Formulario_ventas ventas;
        Formulario_productos productos;
        Formulario_ventasitems ventasitems;
        protected Button boton1;
        protected Button boton2;
        protected Button boton3;
        protected Button boton4;
        public Form1()
        {
            InitializeComponent();
            bll = new BLL_entity();
            boton1 = button1;
            boton2 = button2;
            boton3 = button3;
            boton4 = button4;
        }
        protected void OcultarBotones()
        {
            boton1.Visible = false;
            boton2.Visible = false;
            boton3.Visible = false;
            boton4.Visible = false;
        }
        protected DataGridView PrepararDt(DataGridView dt)
        {
            dt.DataSource = null;
            dt.Rows.Clear();
            return dt;
        }
        public void MostrarDT<T>(DataGridView dt, List<T> list) where T : Entity, new()
        {
            PrepararDt(dt).DataSource = list;
        }
        public bool Alta<T>(object[] d) where T : Entity, new()
        {
            T aux = new T();
            aux.CargarDatos(d);
            return bll.Alta(aux);
        }
        public bool Baja<T>(int id) where T : Entity, new()
        {
            T aux = new T();
            aux.CargarPK(id);
            return bll.Baja(aux);
        }
        public bool Modificacion<T>(object[] d) where T : Entity, new()
        {
            T aux = new T();
            aux.CargarDatos(d);
            return bll.Modificacion(aux);
        }
        protected void CargarDT5<T>(DataGridView dt1, DataGridView dt2, DataGridView dt3, DataGridView dt4, DataGridView dt5) where T : Entity, new()
        {
            MostrarDT(dt1, bll.DevolverTabla(new T()));
            MostrarDT(dt2, bll.MostrarNuevos<T>());
            MostrarDT(dt3, bll.MostrarBorrados<T>());
            MostrarDT(dt4, bll.MostrarModificadosClienteOG<T>());
            MostrarDT(dt5, bll.MostrarModificadosNEW<T>());
        }
        protected void ConsultaDesdeHasta<T>(T entLINF, T entLIS, DataGridView dt6) where T : Entity, new()
        {
            if (ValidarNull(new List<Entity>() { entLINF, entLIS }) && ValidarDesdeHasta(entLINF, entLIS)) MostrarDT(dt6, bll.ConsultaDesdeHastaID(entLINF, entLIS));
        }
        protected void ConsultaIncremental(clientes entINC, DataGridView dt7)
        {
            MostrarDT(dt7, bll.ConsultaIncrementalID(entINC));
        }
        protected void ConsultaXID<T>(T solo, DataGridView dt8) where T : Entity, new()
        {

            if (ValidarNull(new List<Entity>() { solo })) bll.ConsultaID(solo);
            MostrarDT(dt8, new List<T>() { solo });
        }
        protected bool ValidarDesdeHasta(Entity desde, Entity hasta)
        {
            if (desde.ID < hasta.ID) return true;
            return false;
        }
        protected bool ValidarNull(List<Entity> list)
        {
            foreach (Entity ent in list)
            {
                if (ent.ID == 0) return false;
            }
            return true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clientess = new Formulario_clientes();
            clientess.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            productos = new Formulario_productos();
            productos.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ventas = new Formulario_ventas();
            ventas.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ventasitems = new Formulario_ventasitems();
            ventasitems.Show();
        }
    }
}
