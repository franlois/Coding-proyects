﻿using BE;
using BLL;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_capas_2
{
    public partial class Formulario_clientes : Form1
    {
        public Formulario_clientes()
        {
            InitializeComponent();
            OcultarBotones();
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = Interaction.InputBox("ingrese el id");
            string nombre = Interaction.InputBox("ingrese el nombre");
            string telefono = Interaction.InputBox("ingrese el telefono");
            string email = Interaction.InputBox("ingrese el mail");
            object[] d = new object[] { id, nombre, telefono, email };
            if (ValidacionesCliente(d)) Alta<clientes>(d);
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }
        private bool ValidacionesCliente(object[] d)
        {
            if (bll.DevolverTabla(new clientes()).ToList().Find(x => x.ID == Convert.ToInt16(d[0].ToString())) != null) return false;
            Regex mail = new Regex("\r\n^((?!\\.)[\\w\\-_.]*[^.])(@\\w+)(\\.\\w+(\\.\\w+)?[^.\\W])$\r\n");
            if (!mail.IsMatch(d[3].ToString())) return false;
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Baja<clientes>(Convert.ToInt16(dataGridView1.SelectedRows[0].Cells[0].Value.ToString()));
                CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                clientes aux = bll.DevolverTabla(new clientes()).ToList().Find(x => x.ID == Convert.ToInt16(dataGridView1.SelectedRows[0].Cells[0].Value.ToString()));
                string nombre = Interaction.InputBox("ingrese el nombre", "", aux.Nombre);
                string telefono = Interaction.InputBox("ingrese el telefono", "", aux.Telefono.ToString());
                string email = Interaction.InputBox("ingrese el mail", "", aux.Correo);
                object[] d = new object[] { aux.DevolverPK(), nombre, telefono, email };
                if (!d[3].ToString().Contains('@')) Modificacion<clientes>(d);
                CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bll.GrabarEnBd();
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text.Length > 0)
            {
                clientes aux = new clientes();

                    aux.Nombre = textBox3.Text;
                    ConsultaIncremental(aux, dataGridView7);

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0 && Information.IsNumeric(textBox1.Text) && textBox2.Text.Length > 0 && Information.IsNumeric(textBox2.Text))
            {
                clientes aux1 = new clientes();
                clientes aux2 = new clientes();
                aux1.CargarPK(Convert.ToInt16(textBox1.Text));
                aux2.CargarPK(Convert.ToInt16(textBox2.Text));
                ConsultaDesdeHasta(aux1, aux2, dataGridView6);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if(textBox4.Text.Length > 0 && Information.IsNumeric(textBox4.Text))
            {
                clientes aux = new clientes();
                aux.CargarPK(Convert.ToInt16(textBox4.Text));
                ConsultaXID(aux, dataGridView8);
            }
        }
    }
}
