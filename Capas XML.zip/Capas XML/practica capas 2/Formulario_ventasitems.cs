﻿using BE;
using BLL;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_capas_2
{ // hay q probarlo, ver el tema de las modificaciones, y si es posbile abstraer esto
    public partial class Formulario_ventasitems : Form1
    {
        public Formulario_ventasitems()
        {
            InitializeComponent();
            OcultarBotones();
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = Interaction.InputBox("ingrese el id");
            string idventa = Interaction.InputBox("ingrese el id de venta");
            string idproducto = Interaction.InputBox("ingrese el id de producto");
            string precioUnitario = Interaction.InputBox("ingrese el precio unitario");
            string Cantidad = Interaction.InputBox("ingrese la cantidad");
            object[] d = new object[] { id, idventa,idproducto ,precioUnitario, Cantidad, 1};
            if (ValidarVI(d))
            {
                d[5] = (Convert.ToInt16(precioUnitario) * Convert.ToInt16(Cantidad));
                Alta<ventasitems>(d);
                CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
            }
        }
        private bool ValidarVI(object[] d)
        {
            foreach (object o in d) { if(!Information.IsNumeric(o))  return false; }
            List<ventasitems> aux = bll.DevolverTabla(new ventasitems()).ToList();
            if (aux.Find(x => x.ID == Convert.ToInt16(d[0])) == null && bll.DevolverTabla(new ventas()).Find(x => x.ID == Convert.ToInt16(d[1])) != null && bll.DevolverTabla(new productos()).Find(x => x.ID == Convert.ToInt16(d[2])) != null) return true;
            return false;
        }
        private bool ValidarVI2(object[] d)
        {
            foreach (object o in d) { if (!Information.IsNumeric(o)) return false; }
            if (bll.DevolverTabla(new ventas()).Find(x => x.ID == Convert.ToInt16(d[1])) != null && bll.DevolverTabla(new productos()).Find(x => x.ID == Convert.ToInt16(d[2])) != null) return true;
            return false;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Baja<ventasitems>(Convert.ToInt16(dataGridView1.SelectedRows[0].Cells[0].Value.ToString()));
                CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string idventa = Interaction.InputBox("ingrese el id de venta","", dataGridView1.SelectedRows[0].Cells[1].Value.ToString());
            string idproducto = Interaction.InputBox("ingrese el id de producto","", dataGridView1.SelectedRows[0].Cells[2].Value.ToString());
            string precioUnitario = Interaction.InputBox("ingrese el precio unitario","", dataGridView1.SelectedRows[0].Cells[3].Value.ToString());
            string Cantidad = Interaction.InputBox("ingrese el cantidad","" ,dataGridView1.SelectedRows[0].Cells[4].Value.ToString());
            object[] d = new object[] { id, idventa, idproducto, precioUnitario, Cantidad, 1 };
            if (ValidarVI2(d))
            {
                d[5] = Convert.ToInt16(precioUnitario) * Convert.ToInt16(Cantidad);
                Modificacion<ventasitems>(d);
                CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bll.GrabarEnBd();
            CargarDT5<clientes>(dataGridView1, dataGridView2, dataGridView3, dataGridView4, dataGridView5);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0 && Information.IsNumeric(textBox1.Text) && textBox2.Text.Length > 0 && Information.IsNumeric(textBox2.Text))
            {
                ventasitems aux1 = new ventasitems();
                ventasitems aux2 = new ventasitems();
                aux1.CargarPK(Convert.ToInt16(textBox1.Text));
                aux2.CargarPK(Convert.ToInt16(textBox2.Text));
                ConsultaDesdeHasta(aux1, aux2, dataGridView6);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox4.Text.Length > 0 && Information.IsNumeric(textBox4.Text))
            {
                ventasitems aux = new ventasitems();
                aux.CargarPK(Convert.ToInt16(textBox4.Text));
                ConsultaXID(aux, dataGridView8);
            }
        }
    }
}
