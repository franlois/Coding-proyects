﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BE
{
    public class clientes : Entity
    {
        public clientes() { }
        public clientes(int id,string nombre, string telefono, string correo)
        {
            this.ID = id;
            Nombre = nombre;
            Telefono = telefono;
            Correo = correo;
        }
        public clientes(object[] d) : this(Convert.ToInt16(d[0]), d[1].ToString(), (d[2]).ToString(), d[3].ToString())
        {

        }
        public void CargarPK(int ID) { this.ID = ID; }
        public object DevolverPK() => ID;
        public int ID { get; set; }
        public string Nombre {  get; set; }
        public string Telefono {  get; set; }
        public string Correo { get; set; }
        public void CargarDatos(object[] d)
        {
            this.ID = Convert.ToInt16(d[0]);
            Nombre = d[1].ToString();
            Telefono = d[2].ToString();
            Correo = d[3].ToString();
        }
        public object[] DevolverDatos() => new object[] { this.ID, this.Nombre, this.Telefono, this.Correo };
        public  override string ToString() => "clientes";
        public object Clone() => MemberwiseClone();   
    }
}
