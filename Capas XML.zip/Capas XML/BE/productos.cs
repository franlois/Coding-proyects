﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BE
{
    public class productos : Entity
    {
        public productos() { }
        public productos(int id, string nombre, decimal precio, string categoria)
        {
            ID = id;
            Nombre = nombre;
            Precio = precio;
            Categoria = categoria;
        }
        public productos(object[] d) : this(Convert.ToInt16(d[0]), d[1].ToString(), decimal.Parse(d[2].ToString()), d[3].ToString()) { }
        public void CargarDatos(object[] d)
        {
            ID = Convert.ToInt16(d[0]);
            Nombre = d[1].ToString();
            Precio = decimal.Parse(d[2].ToString());
            Categoria = d[3].ToString();
        }
        public object[] DevolverDatos() => new object[] {this.ID, this.Nombre, this.Precio, this.Categoria };
        public override string ToString() => "productos";
        public int ID
        {
            get; set;
        }
        public void CargarPK(int ID) { this.ID = ID; }
        public object DevolverPK() => ID;
        public string Nombre { get; set; }
        public decimal Precio {  get; set; }
        public string Categoria {  get; set; }

        public object Clone() => this.MemberwiseClone();
    }
}
