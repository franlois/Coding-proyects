﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class ventasitems : Entity
    {
        public ventasitems() { }
        public ventasitems(int id, int idV, int idP, decimal pu, int cant, decimal precioTotal) 
        {
            ID = id;
            IDVenta = idV;
            IDProducto = idP;
            PrecioUnitario = pu;
            Cantidad = cant;
            PrecioTotal = precioTotal;
        }
        public ventasitems(object[] d) : this(Convert.ToInt16(d[0]), Convert.ToInt16(d[1]), Convert.ToInt16(d[2]), decimal.Parse(d[3].ToString()), Convert.ToInt16(d[4]), decimal.Parse(d[5].ToString())) { }
        public void CargarDatos(object[] d)
        {
            ID = Convert.ToInt16(d[0]);
            IDVenta = Convert.ToInt16(d[1]);
            IDProducto = Convert.ToInt16(d[2]);
            PrecioUnitario = decimal.Parse(d[3].ToString());
            Cantidad = Convert.ToInt16(d[4]);
            PrecioTotal = decimal.Parse(d[5].ToString());
        }
        public void CargarPK(int ID) { this.ID = ID; }
        public object DevolverPK() => ID;
        public  object[] DevolverDatos() => new object[] {this.ID, this.IDVenta, this.IDProducto, this.PrecioUnitario, this.Cantidad, this.PrecioTotal };
        public override string ToString() => "ventasitems";
        public int ID { get; set; }
        public int IDVenta {  get; set; }
        public int IDProducto { get; set; }
        public decimal PrecioUnitario { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioTotal { get; set; }

        public object Clone() => this.MemberwiseClone();
    }
}
