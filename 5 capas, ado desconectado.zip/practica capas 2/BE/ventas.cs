﻿namespace BE
{
    public class ventas : Entity
    {
        public ventas() { }
        public ventas(int id, int idC, DateTime fecha, decimal total) 
        {
            ID = id;
            IDCliente = idC;
            Fecha = fecha;
            Total = total;
        }
        public ventas(object[] d) : this(Convert.ToInt16(d[0]), Convert.ToInt16(d[1]), DateTime.Parse(d[2].ToString()), decimal.Parse(d[3].ToString())) { }
        public override void CargarDatos(object[] d)
        {
            ID = Convert.ToInt16(d[0]);
            IDCliente = Convert.ToInt16(d[1]);
            Fecha = DateTime.Parse(d[2].ToString());
            Total = decimal.Parse(d[3].ToString());
        }
        public override object[] DevolverDatos() => new object[] {this.ID, this.IDCliente, this.Fecha, this.Total };
        public int IDCliente {  get; set; }
        public DateTime Fecha { get; set; }
        public decimal Total { get; set; }
        public override string ToString() => "ventas";
        public override object Clone() => this.MemberwiseClone();
    }
}
