﻿using BE;
using DAL;
using System.Data;

namespace ORM
{
    public class Mapeador
    {
        ADO_sql ado;
        public Mapeador()
        {
            ado = new ADO_sql(); 
        }
        public List<T> DevolverTabla<T>(T aux1) where T : Entity, new()
        {
            List<T> aux = new List<T>();
            try
            {              
                foreach (DataRow dr in ado.DevolverDataSet().Tables[aux1.ToString()].Rows)
                {
                    aux.Add(new T());
                    aux.Last().CargarDatos(dr.ItemArray);
                }
            }
            catch{ }
            return aux;
        }
        public bool Alta<T>(T entidad) where T : Entity
        {
            if (ado.DevolverDataSet().Tables[entidad.ToString()].Rows.Add(entidad.DevolverDatos()) != null) return true;
            return false;
        }
        public bool Baja<T>(T entidad) where T : Entity
        {
            ado.DevolverDataSet().Tables[entidad.ToString()].Rows.Find(entidad.DevolverPK()).Delete();
            if (ado.DevolverDataSet().Tables[entidad.ToString()].Rows.Find(entidad.DevolverPK()) == null) return true;
            return false;
        }
        public bool Modificacion<T>(T entidad) where T : Entity
        {
            ado.DevolverDataSet().Tables[entidad.ToString()].Rows.Find(entidad.DevolverPK()).ItemArray = entidad.DevolverDatos();
            if (ado.DevolverDataSet().Tables[entidad.ToString()].Rows.Find(entidad.DevolverPK()).ItemArray == entidad.DevolverDatos()) return true;
            return false;
        }
        //un dataset cuenta como objeto SQL? puede estar aca?
        public List<T> ConsultaXestado<T>(DataViewRowState estado, T entity) where T : Entity, new()
        {
            DataView dv = ado.DevolverDataSet().Tables[entity.ToString()].DefaultView;
            dv.RowStateFilter = estado;
            List<T> aux = new List<T>();
            foreach(DataRowView drv in dv)
            {
                aux.Add(new());
                aux.Last().CargarDatos(drv.Row.ItemArray);
            }
            return aux;
        }
        public List<T> ConsultaXCondicion<T>(string condicion, T entidad) where T : Entity, new()
        {
            DataView dv = ado.DevolverDataSet().Tables[entidad.ToString()].DefaultView;
            dv.RowStateFilter = DataViewRowState.CurrentRows;
            dv.RowFilter = condicion;
            List<T> aux = new List<T>();
            foreach (DataRowView drv in dv)
            {
                aux.Add(new());
                aux.Last().CargarDatos(drv.Row.ItemArray);
            }
            return aux;
        }
        public void Guardar(){   ado.Guardar();  }
        // mañana hacer mofidicacion, y hacer alguna manera de devolver las listas de los agregados, borrados, etc.
    }
}
