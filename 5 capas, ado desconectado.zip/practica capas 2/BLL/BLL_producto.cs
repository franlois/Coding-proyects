﻿using BE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    internal class BLL_producto
    {
        public bool AltaProducto(object[] pDatos)
        {
            throw new NotImplementedException();
        }
        public bool BajaProducto(productos pProductos)
        {
            throw new NotImplementedException();
        }
        public bool ModificacionProducto()
        {
            throw new NotImplementedException();
        }
    }
}
