﻿using BE;
using ORM;

namespace BLL
{
    public class BLL_cliente
    {
        Mapeador mapa;
        public BLL_cliente()
        {
            mapa = new Mapeador();
        }
        public bool AltaCliente(clientes cl)
        {
           return mapa.Alta(cl);
        }
        public bool BajaCliente(clientes cl)
        {
            return mapa.Baja(cl);
        }
        public bool ModificacionCliente(clientes cl)
        {
            return mapa.Modificacion(cl);
        }
        public void ConsultaIDCliente(clientes pCliente)
        {
            throw new NotImplementedException();
        }
        public List<clientes> ConsultaDesdeHastaIDCliente(clientes pCliente1, clientes pCliente2)
        {
            throw new NotImplementedException();
        }
        public List<clientes> ConsultaIncrementalIDCliente(clientes pCliente1, clientes pCliente2)
        {
            throw new NotImplementedException();
        }
        public List<clientes> MostrarModificadosClienteOG()
        {
            throw new NotImplementedException();
        }
        public List<clientes> MostrarModificadosClienteNEW()
        {
            return mapa.ConsultaXestado(System.Data.DataViewRowState.ModifiedCurrent, new clientes());
        }
        public List<clientes> MostrarNuevosCliente()
        {
            return mapa.ConsultaXestado(System.Data.DataViewRowState.Added, new clientes());
        }
        public List<clientes> MostrarBorradosCliente()
        {
            throw new NotImplementedException();
        }
        public void GrabarEnBd()
        {
            throw new NotImplementedException();
        }
    }
}
