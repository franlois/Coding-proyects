﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    internal class BLL_ventas
    {
        public void AltaVentas()
        {
            throw new NotImplementedException();
            // nose bien como hacerlo todavia
        }
    }
}
